import React from "react"
import '../../styles/components/layout/Footer.css';

const Footer = (props) => {
    return (
        <footer>
            <p>Derechos reservados. Transportes X año</p>
        </footer>
        
    )
}
export default Footer;