import React from "react"
import '../styles/components/pages/HomePage.css'


const HomePage = (props) => {
    return (
        <main className="holder">
        <div className="homeimg">
          <img src="img/logo/img01.jpg" alt="Avion" />
        </div>
        <div className="colunas">
            <div className="bienvenidos">
                <h2>Bienvenidos</h2>
                <p>
                Tanka es un género de poesía clásica japonesa y uno de los principales
                géneros de la literatura japonesa.
                Tanka literalmente “poema corto”, 
                pertenece a la antigua poesía japonesa llamada “waka 和歌”, 
                es un poema de 31 sílabas formado por cinco versos en el patrón.
                </p>
                <p>
                Tanka es un género de poesía clásica japonesa y uno de los principales
                géneros de la literatura japonesa.
                Tanka literalmente “poema corto”, 
                pertenece a la antigua poesía japonesa llamada “waka 和歌”, 
                es un poema de 31 sílabas formado por cinco versos en el patrón.
                </p>
            </div>
            <div className="testimonios">
                <h2>Testimonios</h2>
                <div className="testimonio">
                    <span className="cita">Simplemente
                      Excelente</span>
                    <span className="autor">Hiroshi -
                      poesía.com</span>
                </div>
            </div>
        </div>
        </main>
    )
}
export default HomePage;