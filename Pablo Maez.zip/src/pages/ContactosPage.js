import React from "react"
import '../styles/components/pages/ContactosPage.css'

const ContactosPage = (props) => {
    return (
        <main>
         <di>
            <h2>Contato Rápido</h2>
            <form action="" method="" className="formulario">
                <p>
                    <label for="nombre">Nombre</label>
                    <input type="text" name="" />
                </p>
                <p>
                    <label for="email">Email</label>
                    <input type="text" name="" />
                </p>
                <p>
                    <label for="telefono">Telefono</label>
                    <input type="text" name="" />
                </p>
                <p>
                    <label for="mensaje">Mensaje</label>
                    <textarea name=""></textarea>
                </p>
                <p classr="acciones"><input type="submit" value="Enviar" />
                </p>
            </form>
         </di>
            <div class="datos">
                <h2>Otras vias  de comunicación</h2>
                <p>Tambien puede contactarse con nosotros usando los siguientes medios</p>
                <ul>
                    <li>Teléfono</li>
                    <li>Email: contacto@transportesx.com.ar</li>
                    <li>Facebook</li>
                    <li>Twitter</li>
                    <li>Skype</li>
                </ul>
            </div>
        </main>
        
    )
}
export default ContactosPage;