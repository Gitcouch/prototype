import React from "react"
import '../../styles/components/layout/Headers.css';

const Header = (props) => {
    return (
        <Header>
            <div className="holder"> 
              <img srs="img/logo.png" width="100" alt="Transportes X" />
              <h1>Transportes X</h1>
            </div>
        </Header>
    )
}
export default Header;